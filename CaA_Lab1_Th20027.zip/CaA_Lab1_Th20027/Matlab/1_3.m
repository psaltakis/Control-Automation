close all ; clear all;
k=500;
b=1;
m=10;
dt=0.05;  %για 0.001 δεν αποτυπώνεται καλά το σήμα μας
t=[1:3000]*dt;
A=[0 1;-k/m -b/m];  %απο θεωρία
x=[1;0];

for i=1:3000
    x_dot = A*x;
    x = x+x_dot*dt;
    x1_log(i) = x(1);  % καταγραφή 1ης κατάστασης(θέση)
    x2_log(i) = x(2);   % καταγραφή 2ης κατάστασης(ταχύτητα)

%για να τυπώνει 
figure(1)
plot(t(1:i),x1_log)
figure(2)
plot(t(1:i),x2_log)
figure(3) %εξέλιξη στον χώρο των καταστάσεων
plot(x1_log, x2_log)
pause(dt)
end
