close all; 
clear all;
 
g=10;
L=0.5;
b=100;
m=1;
dt=0.01;  
t=[1:1000]*dt;
 
x=[1;0];
 
for i=1:1000
 
    x_dot = [x(2);-(g/L)*cos(x(1))-(b/m*L*L)*(x(2))];
 
    x = x+x_dot*dt;
 
    x1_log(i) = x(1);  % καταγραφή 1ης κατάστασης για τη θέση

 
    x2_log(i) = x(2);  % καταγραφή 2ης κατάστασης για τη ταχύτητα
end
 
%για την αναπαράσταση των plot 
figure(1)
plot(t(1:i),x1_log)
title("position")
xlabel("time")
 
figure(2)
plot(t(1:i),x2_log)
title("velocity")
xlabel("time")
 
 
figure(3)
plot(x1_log,x2_log)
title("State")
xlabel("time")
 
figure(4)
plot_pendulum(x(1))
% pause(dt)
 


