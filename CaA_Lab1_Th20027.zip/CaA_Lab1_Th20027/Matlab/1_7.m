clear all; clc; close all; 
  
  
  
 g=10.0; 
 dt=0.05; 
 t=[1:300]*dt; 
 b=5; 
  
 u=0; 
 m=10; 
 l=0.5; 
 x=[pi/2.0; 0.0]; 
  
  
 for i=1:300 
     x_dot=[x(2);-(g/l)*cos(x(1))-(b/(m*l*l))*x(2)]+[0; u/(m*l*l)]; 
     x=x+x_dot*dt; 
     x1_log(i)=x(1); 
     x2_log(i)=x(2); 
     if t(i)<0.5 
         u=100; 
     else 
         u=0; 
     end 
  
  
     %pendulum plot 
     figure(4) 
     plot_pendulum(x(1)); 
     pause(dt) 
 end 
     figure(1) 
     plot(t(1:i),x1_log) 
     figure(2) 
     plot(t(1:i),x2_log) 
     figure(3) 
     plot(x1_log,x2_log)
