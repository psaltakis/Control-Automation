close all; clear all; clc;
dt=0.001; %vhma
t=[1:300]*dt;
L=1;
C=0.01;
R=100;
A=[0.0,1.0; -1/L*C ,-R/L];
x=[1.0;0];

for i=1:400
  x_dot=A*x;
  x=x+x_dot*dt;
  x1_log(i)=x(1);
  x2_log(i)=x(2);
end

figure(1)
plot(t,x1_log)
title('Voltage')
figure(2)
plot(t,x2_log)
title('Voltage Dot')
figure(3)
plot(x1_log,x2_log) %state space
title('State Space')
