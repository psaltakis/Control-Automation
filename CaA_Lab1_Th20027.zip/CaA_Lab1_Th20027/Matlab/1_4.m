close all;
clear all;

function plot_pendulum(theta)
  L = 0.5;
  x = L * cos(theta);
  y = L * sin(theta);

  plot([-0.5 0.5],[0 0],'k','LineWidth',2)
  hold on 
  plot([0 0],[0 -L],':k','LineWidth',2)
  plot(0,-L,'ok','LineWidth',1)
  plot([0 x],[0 y],'k', 'LineWidth',6)
  plot([x],[y],'*k', 'MarkerSize',12 , 'LineWidth',4)
  plot(0,0,'or', 'MarkerSize',10 , 'LineWidth',4)
  hold off
  axis equal
end



