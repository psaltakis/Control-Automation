clear all; close all; clc;

x0=[1.0; 0];
dt=0.001;
t=[0:4000]*dt;

for i=1:4001
    t_now=t(i);

    Phi= [-0.01*exp(-98.98*t_now)+1.01*exp(-1.01*t_now) -0.01*exp(-98.98*t_now)+0.01*exp(-1.01*t_now); 
        1.02*exp(-98.98*t_now)-1.01*exp(-1.01*t_now) 1.01*exp(-98.98*t_now)-0.01*exp(-1.01*t_now)];

    x_log(:,i)=Phi*x0;
end
plot(t,x_log);