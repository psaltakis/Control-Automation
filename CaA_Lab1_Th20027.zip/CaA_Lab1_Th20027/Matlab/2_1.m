close all; clear all; clc;


dt=0.01;
t=[1:300]*dt;

R=100;
L=1;
C=0.01;
A=[0 1; -1/(L*C) -R/L];
x=[1.0; 0];

for i=1:300
    x_dot=A*x;
    x=x+x_dot*dt;
    x1_log(i)=x(1);
    x2_log(i)=x(2);
    x_current=[x1_log,x2_log];
    figure(1)
    plot (t(1:i),x1_log)
    hold on
    plot(t(1:i),x2_log)
    title('Voltage x1 x2')


    pause(0.05);
    figure(2)
    plot(x1_log,x2_log)
    title('State Space')

end

