dt=1/12 ;  
t=[1:60]*dt;  
x=[300;730];  
A=[10 -3; 3 2];
B=[1 ; 1];
R=[B A*B]
R'   
inv(R') 
syms s; 
a = coeffs(det(s*eye(2,2)-A))  
gama = [1 0 ; -12 1]
inv(gama)
d = coeffs((s+1)*(s+10))  
C=[11-(-12) ; 10-(29)]
kappa = inv(R')*inv(gama)*C
kappa = kappa'
x=[500;730];  
for i=1:60
    u=-kappa*x;
    x_dot = A*x +B*u;
    x = x+x_dot*dt;

if(x(1)<0)
    x(1)=0
end 

if (x(2)<0)
    x(2)=0
end 
    x1_log(i) = x(1);  
    x2_log(i) = x(2);  
    u_log(i) = u;
end
figure(1)
plot(t(1:i),x1_log)
title("Εξέλιξη κουνελιών")
xlabel("time: years")
ylabel("Population")

figure(2)
plot(t(1:i),x2_log)
title("Εξέλιξη αλεπούδων")
xlabel("time: years")
ylabel("Population")

figure(3)
plot(x1_log, x2_log)
title("Εξέλιξη στον Χώρο Καταστάσεων")
xlabel("time: years")

figure(4)
plot(t(1:i), u_log)
title("U through time")  
xlabel("time")



