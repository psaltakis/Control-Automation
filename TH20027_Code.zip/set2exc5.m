close all; clear all; clc;


dt=0.001;
t=[0:3999]*dt;

R=100;
L=1;
C=0.01;
A=[0 1; -1/(L*C) -R/L];
x=[1.0; 0];
C1=[1 0];
zd=[0;0];

[U,L]=eig(A)
G=C1*U
%z=[5;5];
%z=inv(U)*[1;0]
z=[1; 0];
z0=z;
%z=[0; 1]; %2nd test (uncomment and comment the above)
for i=1:4000
    %euler
    z=z+zd*dt;
    zd=L*z;
    y=G*z;
    z1_log(i)=z(1);
    z2_log(i)=z(2);
    z_current=[z1_log,z2_log];
    ylog(i)=y;
    
    %gia thn diagwnopoihsh
    
    z_an=[exp(L(1,1) * t(i)) * z0(1);exp(L(2,2) * t(i)) * z0(2)];
    z1_an_log(i)=z_an(1);
    z2_an_log(i)=z_an(2);
    
    
end
    
    figure(1)
    plot(z1_log, z2_log) 
    title('State Space') 
    figure(2)
    plot(z1_an_log,z2_an_log)
    title('Analytic state space')
    figure(3)
    plot(z1_log, z2_log) 
    hold on
    plot(z1_an_log,z2_an_log)
    hold off
    title('State space of Both')

   




