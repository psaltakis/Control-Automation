close all; 
clear all; 
clc;

%erwthma 1
A=[10 -3; 3 2];
B=[1 ; 1];
eig_values = eig(A);
eig_values

dt=1/12 ;  
t=[1:60]*dt;  
x=[500;730]; 

for i=1:60
    x_dot = A*x;
    x = x+x_dot*dt;

    x1_log(i) = x(1);  
    x2_log(i) = x(2);   

end

figure(1)
plot(t(1:i),x1_log)
title("Εξέλιξη κουνελιών")
xlabel("time: years")
ylabel("Population")

figure(2)
plot(t(1:i),x2_log)
title("Εξέλιξη αλεπούδων")
xlabel("time: years")
ylabel("Population")

figure(3)
plot(x1_log, x2_log)
title("Εξέλιξη στον Χώρο Καταστάσεων")
xlabel("time: years")

eig_values = eig(A);
