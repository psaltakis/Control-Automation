close all
clear all 

m1 = 0.18;
m2 = 0.125;
L = 0.3365/2.0;
b1 = 5.8;
b2 = 3.5e-4;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% CHANGE THESE GAINS !%%%%

K = [0 0 0 0];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


dt = 0.001;
tf = 5.0;

t = [0:dt:tf];

x = [ 0 ; pi/2-0.7 ; 0 ; 0 ];

xdot = [ 0 ; 0 ; 0 ; 0 ];
gconst = 9.81;



for i=1:length(t)
    
   x1 = x(1);
   x2 = x(2);
   x3 = x(3);
   x4 = x(4);
   
   
   
   x = x + xdot*dt;
   
   M = [m1+m2   -m2*L*sin(x2);  -m2*L*sin(x2)  m2*L^2];
   C = [0 m2*L*cos(x2)*x4 ; 0 0];
   g = [0 ; m2*gconst*L*cos(x2)];
   
   u_current = -K*(x-[0;pi/2;0;0]);
   
   xdot = [x(3:4) ; -inv(M)*((-C+diag([b1 b2]))*x(3:4)+g-[u_current;0])];
   
    %(C+diag([b1 b2]))*x(3:4)+
   
   if(mod(i,60)==0)
    plot_poleOnCart(x1,x2);
    pause(0.2*60*dt)
   end
   
   
   xc(i) = x(1);
   theta(i) = x(2);
   u(i) = u_current;
   
    
end

figure;
subplot(3,1,1);
plot(t,xc);
xlabel('Time (s)');
ylabel('Position of cart (m)');

subplot(3,1,2);
plot(t,theta);
xlabel('Time (s)');
ylabel('Angle of pendulums (rad)');

subplot(3,1,3);
plot(t,u);
xlabel('Time (s)');
ylabel('Control input');

