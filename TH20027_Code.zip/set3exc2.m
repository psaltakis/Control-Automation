close all; 
clear all; 
clc;

A=[10 -3; 3 2];
B=[1 ; 1];
dt=1/12 ;   
t=[1:60]*dt;  
x=[330;730];  
%όριο που εξαφανίζονται τα κουνέλια 
for i=1:60
    x_dot = A*x;
    x = x+x_dot*dt;
if(x(1)<0)
    x(1)=0
end 
if (x(2)<0)
    x(2)=0
end 
    x1_log(i) = x(1);   
    x2_log(i) = x(2);    
end
figure(1)
plot(t(1:i),x1_log)
title("Εξέλιξη κουνελιών")
xlabel("time: years")
ylabel("Population")
%περίπου σε 8 -8,5 μήνες θα εκλείψουν τα κουνέλια 
figure(2)
plot(t(1:i),x2_log)
title("Εξέλιξη αλεπούδων")
xlabel("time: years")
ylabel("Population")
figure(3)
plot(x1_log, x2_log)
title("Εξέλιξη στον Χώρο Καταστάσεων")
xlabel("time: years")
