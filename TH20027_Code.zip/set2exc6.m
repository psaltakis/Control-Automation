close all; clear all; clc;


dt=0.001;
t=[0:3999]*dt;
R=100;
L=1;
C=0.01;
A=[0 1; -1/(L*C) -R/L];
x=[1.0; 0];
C1=[1 0];
zd=[0;0];
[U,L]=eig(A)
G=C1*U
z=[1; 0];
z0=z;
u = exp(-4 * t);

for i = 1:4000
    z = z + (zd * dt) + (u(i) * dt);
    zd = L * z;
    y = G * z;
    z1_log(i) = z(1);
    z2_log(i) = z(2);
    z_current = [z1_log, z2_log];
    ylog(i) = y;

end
figure(1)
plot(t(1:i),ylog)
title('ΕΞΟΔΟΣ ΕΡΩΤΗΜΑΤΟΣ 6')
figure(2)
 plot (t(1:i),z1_log)
 hold on
 plot(t(1:i),z2_log)
 title('z1 z2 ΕΡΩΤΗΜΑΤΟΣ 6')
 figure(3)
 plot(z1_log, z2_log) 
 title('State Space') 



