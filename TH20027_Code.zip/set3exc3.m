A=[10 -3; 3 2];
B=[1 ; 1];
R=[B A*B];
n=rank(R)

if(n==2)
    
    disp("The system is controllable.")

end