close all; 
clear all; 
clc;

dt=0.001;
t=[0:4000-1]*dt;
L=1;
C=0.01;
R=100;
A=[0 1; -1/(L*C) -R/L];
C1=[1 0];
zd=[0;0];

[U, Lamda] = eig(A);

G=C1*U;

z=[1; 0];

for i = 1:4000
    
    z=z+zd*dt;
    zd=Lamda*z;
    y=G*z;  
    z1_log(i)=z(1);
    z2_log(i)=z(2);
    y_log(i)=y;

    
end 

figure(1)
plot(t(1:i),y_log)
title('ΕΞΟΔΟΣ ΕΡΩΤΗΜΑΤΟΣ 3')
figure(2)
 plot (t(1:i),z1_log)
 hold on
 plot(t(1:i),z2_log)
 title('z1 z2 ΕΡΩΤΗΜΑΤΟΣ 3')
 
U
Lamda
G