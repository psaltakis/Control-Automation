A = [0 0 1 0; 0 0 0 1; 0 4.35 -27.99 -0.01; 0 63.1 -124.71 -0.19];
B = [0; 0;4.73;21.09];
C = [1 0 0 0];

poles = [-2 -20 -30 -40];
K = place(A,B,poles); % Control gain 

sys_cl = ss(A-B*K,B,C,0); % Closed-loop

t = 0:0.1:10; 
[y,t,x] = step(sys_cl,t); 
figure; 
plot(t,y); 
xlabel('Time (s)');
ylabel('Position of cart (m)');



figure; 
plot(t,x); 
xlabel('Time (s)');
ylabel('State');
legend('x1','x2','x3','x4'); 

K